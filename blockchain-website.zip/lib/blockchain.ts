// This file contains functions to interact with the blockchain

import { ethers } from "ethers"

// Check if window is defined (browser) or not (server)
const isBrowser = typeof window !== "undefined"

// Mock data for development purposes
const mockStats = {
  gasPrice: "45 Gwei",
  latestBlock: 17584930,
  activeNodes: 9823,
  marketCap: "$219.5B",
}

const mockTransactions = [
  {
    id: "0x7a9d852b39c1dbe0a5a67c90ff0a288c044a644789a71e769e35e1a795c8c168",
    from: "0x71C7656EC7ab88b098defB751B7401B5f6d8976F",
    to: "0x8626f6940E2eb28930eFb4CeF49B2d1F2C9C1199",
    amount: "1.25",
    timestamp: Date.now() / 1000 - 3600, // 1 hour ago
    status: "confirmed" as const,
  },
  {
    id: "0x9b7bb827e1e2b5b2e4793f1aad1d00f443ddc58ef1e28d3e19c63ae6d0fd4557",
    from: "0x8626f6940E2eb28930eFb4CeF49B2d1F2C9C1199",
    to: "0x71C7656EC7ab88b098defB751B7401B5f6d8976F",
    amount: "0.5",
    timestamp: Date.now() / 1000 - 7200, // 2 hours ago
    status: "confirmed" as const,
  },
  {
    id: "0x3a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a1b",
    from: "0x71C7656EC7ab88b098defB751B7401B5f6d8976F",
    to: "0x2B5AD5c4795c026514f8317c7a215E218DcCD6cF",
    amount: "0.1",
    timestamp: Date.now() / 1000 - 86400, // 1 day ago
    status: "pending" as const,
  },
]

// Get provider based on environment
const getProvider = () => {
  if (!isBrowser) {
    throw new Error("Cannot access Ethereum provider on server")
  }

  // Check if MetaMask or other injected provider is available
  if (window.ethereum) {
    return new ethers.BrowserProvider(window.ethereum)
  }

  // Fallback to a public provider (for read-only operations)
  return new ethers.JsonRpcProvider("https://eth-mainnet.g.alchemy.com/v2/demo")
}

// Connect wallet
export const connectWallet = async (): Promise<string> => {
  if (!isBrowser) {
    throw new Error("Cannot connect wallet on server")
  }

  if (!window.ethereum) {
    throw new Error("No Ethereum wallet found. Please install MetaMask or another wallet.")
  }

  try {
    const provider = getProvider()
    const accounts = await provider.send("eth_requestAccounts", [])

    if (accounts.length === 0) {
      throw new Error("No accounts found")
    }

    return accounts[0]
  } catch (error) {
    console.error("Error connecting wallet:", error)
    throw error
  }
}

// Disconnect wallet (clear state only, as there's no real "disconnect" in MetaMask)
export const disconnectWallet = async (): Promise<void> => {
  // This is just a placeholder as there's no standard way to disconnect
  // In a real app, you would clear your app's state
  return Promise.resolve()
}

// Get current wallet address
export const getWalletAddress = async (): Promise<string | null> => {
  if (!isBrowser || !window.ethereum) {
    return null
  }

  try {
    const provider = getProvider()
    const accounts = await provider.send("eth_accounts", [])
    return accounts[0] || null
  } catch (error) {
    console.error("Error getting wallet address:", error)
    return null
  }
}

// Fetch blockchain stats
export const fetchBlockchainStats = async () => {
  // In a real app, you would fetch this data from a blockchain API
  // For this example, we'll use mock data

  // Simulate API call delay
  await new Promise((resolve) => setTimeout(resolve, 1000))

  return mockStats
}

// Fetch transactions
export const fetchTransactions = async () => {
  // In a real app, you would fetch this data from a blockchain API
  // For this example, we'll use mock data

  // Simulate API call delay
  await new Promise((resolve) => setTimeout(resolve, 1500))

  return mockTransactions
}

// Send transaction
export const sendTransaction = async (to: string, amount: number): Promise<string> => {
  if (!isBrowser) {
    throw new Error("Cannot send transaction on server")
  }

  if (!window.ethereum) {
    throw new Error("No Ethereum wallet found. Please install MetaMask.")
  }

  try {
    const provider = getProvider()
    const signer = await provider.getSigner()

    // Convert amount to wei
    const amountInWei = ethers.parseEther(amount.toString())

    // Create transaction
    const tx = await signer.sendTransaction({
      to,
      value: amountInWei,
    })

    // Wait for transaction to be mined
    await tx.wait()

    return tx.hash
  } catch (error) {
    console.error("Error sending transaction:", error)
    throw error
  }
}

