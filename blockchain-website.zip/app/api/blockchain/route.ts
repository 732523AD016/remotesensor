import { NextResponse } from "next/server"

// Mock data for blockchain API
const mockBlockchainData = {
  stats: {
    gasPrice: "45 Gwei",
    latestBlock: 17584930,
    activeNodes: 9823,
    marketCap: "$219.5B",
  },
  transactions: [
    {
      id: "0x7a9d852b39c1dbe0a5a67c90ff0a288c044a644789a71e769e35e1a795c8c168",
      from: "0x71C7656EC7ab88b098defB751B7401B5f6d8976F",
      to: "0x8626f6940E2eb28930eFb4CeF49B2d1F2C9C1199",
      amount: "1.25",
      timestamp: Math.floor(Date.now() / 1000) - 3600, // 1 hour ago
      status: "confirmed",
    },
    {
      id: "0x9b7bb827e1e2b5b2e4793f1aad1d00f443ddc58ef1e28d3e19c63ae6d0fd4557",
      from: "0x8626f6940E2eb28930eFb4CeF49B2d1F2C9C1199",
      to: "0x71C7656EC7ab88b098defB751B7401B5f6d8976F",
      amount: "0.5",
      timestamp: Math.floor(Date.now() / 1000) - 7200, // 2 hours ago
      status: "confirmed",
    },
    {
      id: "0x3a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a1b",
      from: "0x71C7656EC7ab88b098defB751B7401B5f6d8976F",
      to: "0x2B5AD5c4795c026514f8317c7a215E218DcCD6cF",
      amount: "0.1",
      timestamp: Math.floor(Date.now() / 1000) - 86400, // 1 day ago
      status: "pending",
    },
  ],
}

// GET handler for blockchain stats
export async function GET() {
  try {
    // In a real application, you would fetch this data from a blockchain node or API
    return NextResponse.json(mockBlockchainData.stats)
  } catch (error) {
    return NextResponse.json({ error: "Failed to fetch blockchain data" }, { status: 500 })
  }
}

// POST handler for submitting transactions
export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { to, amount } = body

    // Validate request
    if (!to || !amount) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    // In a real application, you would submit this transaction to the blockchain
    // For this example, we'll just return a mock transaction hash
    const txHash =
      "0x" +
      Array(64)
        .fill(0)
        .map(() => Math.floor(Math.random() * 16).toString(16))
        .join("")

    return NextResponse.json({
      success: true,
      txHash,
      message: "Transaction submitted successfully",
    })
  } catch (error) {
    return NextResponse.json({ error: "Failed to process transaction" }, { status: 500 })
  }
}

