"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { connectWallet, disconnectWallet, getWalletAddress } from "@/lib/blockchain"
import { Loader2 } from "lucide-react"

export function WalletConnect() {
  const [address, setAddress] = useState<string | null>(null)
  const [connecting, setConnecting] = useState(false)

  useEffect(() => {
    // Check if wallet is already connected
    const checkConnection = async () => {
      const walletAddress = await getWalletAddress()
      if (walletAddress) {
        setAddress(walletAddress)
      }
    }

    checkConnection()
  }, [])

  const handleConnect = async () => {
    setConnecting(true)
    try {
      const walletAddress = await connectWallet()
      setAddress(walletAddress)
    } catch (error) {
      console.error("Failed to connect wallet:", error)
    } finally {
      setConnecting(false)
    }
  }

  const handleDisconnect = async () => {
    try {
      await disconnectWallet()
      setAddress(null)
    } catch (error) {
      console.error("Failed to disconnect wallet:", error)
    }
  }

  if (address) {
    return (
      <div className="flex items-center gap-4">
        <div className="bg-muted px-4 py-2 rounded-full text-sm flex items-center">
          <div className="w-2 h-2 rounded-full bg-green-500 mr-2"></div>
          <span className="font-mono">
            {address.substring(0, 6)}...{address.substring(address.length - 4)}
          </span>
        </div>
        <Button variant="outline" onClick={handleDisconnect} size="sm">
          Disconnect
        </Button>
      </div>
    )
  }

  return (
    <Button onClick={handleConnect} disabled={connecting}>
      {connecting ? (
        <>
          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
          Connecting...
        </>
      ) : (
        "Connect Wallet"
      )}
    </Button>
  )
}

