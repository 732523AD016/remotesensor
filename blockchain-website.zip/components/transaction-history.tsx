"use client"

import { useEffect, useState } from "react"
import { fetchTransactions } from "@/lib/blockchain"
import { Skeleton } from "@/components/ui/skeleton"
import { Badge } from "@/components/ui/badge"

interface Transaction {
  id: string
  from: string
  to: string
  amount: string
  timestamp: number
  status: "confirmed" | "pending" | "failed"
}

export function TransactionHistory() {
  const [transactions, setTransactions] = useState<Transaction[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const getTransactions = async () => {
      try {
        const data = await fetchTransactions()
        setTransactions(data)
      } catch (error) {
        console.error("Failed to fetch transactions:", error)
      } finally {
        setLoading(false)
      }
    }

    getTransactions()
  }, [])

  if (loading) {
    return (
      <div className="space-y-4">
        {Array.from({ length: 5 }).map((_, i) => (
          <div key={i} className="flex items-center space-x-4">
            <Skeleton className="h-12 w-12 rounded-full" />
            <div className="space-y-2">
              <Skeleton className="h-4 w-[250px]" />
              <Skeleton className="h-4 w-[200px]" />
            </div>
          </div>
        ))}
      </div>
    )
  }

  if (transactions.length === 0) {
    return (
      <div className="text-center py-10">
        <p className="text-muted-foreground">No transactions found</p>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      {transactions.map((tx) => (
        <div key={tx.id} className="flex flex-col space-y-2 border-b pb-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-2">
              <span className="font-medium">Transaction</span>
              <span className="text-xs font-mono text-muted-foreground">{tx.id.substring(0, 8)}...</span>
            </div>
            <Badge
              variant={tx.status === "confirmed" ? "default" : tx.status === "pending" ? "outline" : "destructive"}
            >
              {tx.status}
            </Badge>
          </div>
          <div className="grid grid-cols-2 gap-2 text-sm">
            <div>
              <p className="text-muted-foreground">From</p>
              <p className="font-mono">
                {tx.from.substring(0, 6)}...{tx.from.substring(tx.from.length - 4)}
              </p>
            </div>
            <div>
              <p className="text-muted-foreground">To</p>
              <p className="font-mono">
                {tx.to.substring(0, 6)}...{tx.to.substring(tx.to.length - 4)}
              </p>
            </div>
          </div>
          <div className="flex justify-between items-center text-sm">
            <div>
              <span className="text-muted-foreground mr-1">Amount:</span>
              <span className="font-medium">{tx.amount} ETH</span>
            </div>
            <div className="text-muted-foreground">{new Date(tx.timestamp * 1000).toLocaleString()}</div>
          </div>
        </div>
      ))}
    </div>
  )
}

